document.getElementById('inicio').addEventListener('click', function() {
    window.history.back();
});

document.getElementById("confirmar").addEventListener('click', function(){
    location.href = 'confirmar.html'
})